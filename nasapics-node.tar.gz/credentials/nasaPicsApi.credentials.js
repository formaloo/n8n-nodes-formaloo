"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nasaPicsApi = void 0;
class nasaPicsApi {
    constructor() {
        this.name = 'nasaPicsApi';
        this.displayName = 'NASA Pics API';
        this.documentationUrl = 'https://docs.n8n.io/integrations/creating-nodes/build/declarative-style-node/';
        this.properties = [
            {
                displayName: 'API Key',
                name: 'apiKey',
                type: 'string',
                typeOptions: {
                    password: true,
                },
                default: '',
            },
        ];
        this.authenticate = {
            type: 'generic',
            properties: {
                qs: {
                    'api_key': '={{$credentials.apiKey}}'
                }
            },
        };
    }
}
exports.nasaPicsApi = nasaPicsApi;
//# sourceMappingURL=nasaPicsApi.credentials.js.map