import { INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class NasaPics implements INodeType {
    description: INodeTypeDescription;
}
