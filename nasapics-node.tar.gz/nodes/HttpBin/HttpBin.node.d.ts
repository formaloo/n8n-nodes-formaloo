import { INodeType, INodeTypeDescription } from 'n8n-workflow';
export declare class HttpBin implements INodeType {
    description: INodeTypeDescription;
}
